"""Runs the Flask app in its own thread (the 'web dashboard server' thread)."""
import logging
import threading

from werkzeug.serving import make_server

import config
from web.app import create_app

log = logging.getLogger("web")


class WebServer(threading.Thread):
    def __init__(self, state, stop_evt):
        super().__init__(name="web-server", daemon=True)
        self.state, self.stop_evt = state, stop_evt

    def run(self):
        app = create_app(self.state)
        srv = make_server(config.WEB_HOST, config.WEB_PORT, app, threaded=True)
        log.info("web server on http://%s:%d", config.WEB_HOST, config.WEB_PORT)
        worker = threading.Thread(target=srv.serve_forever, daemon=True)
        worker.start()
        self.stop_evt.wait()
        srv.shutdown()
