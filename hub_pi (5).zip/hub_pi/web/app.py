"""Flask API: login, users, sessions, summaries, PDF reports, live WebSocket."""
import io
import json
import logging
import os
import re
import secrets
import time
from functools import wraps

from flask import Flask, g, jsonify, request, send_file, send_from_directory, session
from flask_sock import Sock
from werkzeug.security import check_password_hash, generate_password_hash

import config
from web import analytics, db, report

log = logging.getLogger("web")
ROLES = ("patient", "physio", "admin")
STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")


def _secret_key():
    path = os.path.join(os.path.dirname(config.DB_PATH), "secret_key")
    if not os.path.exists(path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as fh:
            fh.write(secrets.token_hex(32))
        os.chmod(path, 0o600)
    return open(path).read().strip()


def err(msg, code=400):
    return jsonify(error=msg), code


def _num(v, lo, hi):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return None
    return v if lo <= v <= hi else None


def clean_profile(d, partial=False):
    """Validate profile fields. Returns (dict, error)."""
    out = {}
    if "full_name" in d:
        out["full_name"] = str(d["full_name"]).strip()[:80]
    rules = {"age": (5, 110), "height_cm": (80, 230), "weight_kg": (20, 300)}
    for k, (lo, hi) in rules.items():
        if k in d:
            v = _num(d[k], lo, hi)
            if v is None:
                return None, f"{k} must be between {lo} and {hi}"
            out[k] = int(v) if k == "age" else v
    if "sex" in d:
        if d["sex"] not in ("male", "female", "other"):
            return None, "sex must be male, female or other"
        out["sex"] = d["sex"]
    if not partial and not all(k in out for k in ("age", "sex", "height_cm", "weight_kg")):
        return None, "age, sex, height_cm and weight_kg are required"
    return out, None


def create_app(state):
    app = Flask(__name__, static_folder=None)
    app.config.update(SECRET_KEY=_secret_key(), SESSION_COOKIE_HTTPONLY=True,
                      SESSION_COOKIE_SAMESITE="Lax", PERMANENT_SESSION_LIFETIME=8 * 3600)
    sock = Sock(app)
    admin_pw = db.init_db()
    if admin_pw:
        log.warning("FIRST RUN: created user 'admin' with password: %s (change it, shown once)", admin_pw)
    fails = {}   # (ip, username) -> [timestamps]

    @app.before_request
    def load_user():
        g.db = db.connect()
        g.user = None
        uid = session.get("uid")
        if uid:
            g.user = g.db.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()

    @app.teardown_request
    def close_db(_exc):
        conn = g.pop("db", None)
        if conn:
            conn.close()

    @app.after_request
    def headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        if request.path.startswith("/api"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    def login_required(f):
        @wraps(f)
        def wrapper(*a, **k):
            if g.user is None:
                return err("login required", 401)
            return f(*a, **k)
        return wrapper

    def role_required(*roles):
        def deco(f):
            @wraps(f)
            def wrapper(*a, **k):
                if g.user is None:
                    return err("login required", 401)
                if g.user["role"] not in roles:
                    return err("not allowed", 403)
                return f(*a, **k)
            return wrapper
        return deco

    def accessible_ids(conn, user):
        """Set of user ids this user may view, or None for everyone (admin)."""
        if user["role"] == "admin":
            return None
        ids = {user["id"]}
        if user["role"] == "physio":
            ids |= {r[0] for r in conn.execute(
                "SELECT patient_id FROM assignments WHERE physio_id=?", (user["id"],))}
        return ids

    def can_access(target_id):
        ids = accessible_ids(g.db, g.user)
        return ids is None or target_id in ids

    def profile_of(uid):
        r = g.db.execute("SELECT * FROM profiles WHERE user_id=?", (uid,)).fetchone()
        return dict(r) if r else {}

    # ---------------- auth ----------------
    @app.post("/api/login")
    def login():
        d = request.get_json(silent=True) or {}
        username, password = str(d.get("username", "")), str(d.get("password", ""))
        key = (request.remote_addr, username.lower())
        now = time.time()
        recent = [t for t in fails.get(key, []) if now - t < config.LOGIN_LOCK_S]
        if len(recent) >= config.LOGIN_MAX_FAILS:
            return err("too many attempts, wait a minute", 429)
        u = g.db.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if not u or not check_password_hash(u["password_hash"], password):
            fails[key] = recent + [now]
            return err("wrong username or password", 401)
        fails.pop(key, None)
        session.clear()
        session["uid"] = u["id"]
        session.permanent = True
        return jsonify(id=u["id"], username=u["username"], role=u["role"])

    @app.post("/api/logout")
    def logout():
        session.clear()
        return jsonify(ok=True)

    @app.get("/api/me")
    @login_required
    def me():
        return jsonify(id=g.user["id"], username=g.user["username"], role=g.user["role"],
                       profile=profile_of(g.user["id"]))

    @app.put("/api/profile")
    @login_required
    def update_profile():
        p, e = clean_profile(request.get_json(silent=True) or {}, partial=True)
        if e:
            return err(e)
        if p:
            cols = ",".join(f"{k}=?" for k in p)
            g.db.execute(f"INSERT OR IGNORE INTO profiles(user_id) VALUES(?)", (g.user["id"],))
            g.db.execute(f"UPDATE profiles SET {cols} WHERE user_id=?", (*p.values(), g.user["id"]))
            g.db.commit()
        return jsonify(profile=profile_of(g.user["id"]))

    # ---------------- users (admin) ----------------
    @app.post("/api/users")
    @role_required("admin")
    def create_user():
        d = request.get_json(silent=True) or {}
        username, password, role = str(d.get("username", "")), str(d.get("password", "")), d.get("role")
        if not re.fullmatch(r"[A-Za-z0-9_]{3,32}", username):
            return err("username: 3 to 32 letters, digits or underscore")
        if len(password) < 8:
            return err("password must be at least 8 characters")
        if role not in ROLES:
            return err("role must be patient, physio or admin")
        prof, e = clean_profile(d, partial=(role != "patient"))
        if e:
            return err(e)
        if g.db.execute("SELECT 1 FROM users WHERE username=?", (username,)).fetchone():
            return err("username already exists", 409)
        cur = g.db.execute("INSERT INTO users(username,password_hash,role,created) VALUES(?,?,?,?)",
                           (username, generate_password_hash(password), role, time.time()))
        uid = cur.lastrowid
        g.db.execute("INSERT INTO profiles(user_id) VALUES(?)", (uid,))
        if prof:
            cols = ",".join(f"{k}=?" for k in prof)
            g.db.execute(f"UPDATE profiles SET {cols} WHERE user_id=?", (*prof.values(), uid))
        g.db.commit()
        return jsonify(id=uid, username=username, role=role), 201

    @app.get("/api/users")
    @login_required
    def list_users():
        ids = accessible_ids(g.db, g.user)
        rows = g.db.execute("SELECT u.id, u.username, u.role, p.full_name, p.age, p.sex "
                            "FROM users u LEFT JOIN profiles p ON p.user_id=u.id ORDER BY u.id").fetchall()
        return jsonify([dict(r) for r in rows if ids is None or r["id"] in ids])

    @app.post("/api/assign")
    @role_required("admin")
    def assign():
        d = request.get_json(silent=True) or {}
        ph = g.db.execute("SELECT role FROM users WHERE id=?", (d.get("physio_id"),)).fetchone()
        pa = g.db.execute("SELECT role FROM users WHERE id=?", (d.get("patient_id"),)).fetchone()
        if not ph or ph["role"] != "physio" or not pa or pa["role"] != "patient":
            return err("physio_id must be a physio and patient_id a patient")
        g.db.execute("INSERT OR IGNORE INTO assignments VALUES(?,?)", (d["physio_id"], d["patient_id"]))
        g.db.commit()
        return jsonify(ok=True)

    # ---------------- sessions ----------------
    def metrics_for(sess):
        r = g.db.execute("SELECT json FROM session_metrics WHERE session_id=?", (sess["id"],)).fetchone()
        if r:
            return json.loads(r["json"])
        f = analytics.session_features(g.db, sess["start_ts"], sess["end_ts"])
        g.db.execute("INSERT OR REPLACE INTO session_metrics VALUES(?,?)", (sess["id"], json.dumps(f)))
        g.db.commit()
        return f

    def get_session(sid):
        s = g.db.execute("SELECT * FROM sessions WHERE id=?", (sid,)).fetchone()
        if not s or not can_access(s["user_id"]):
            return None
        return s

    @app.post("/api/sessions/start")
    @login_required
    def start_session():
        d = request.get_json(silent=True) or {}
        target = d.get("user_id", g.user["id"])
        target_row = g.db.execute("SELECT role FROM users WHERE id=?", (target,)).fetchone()
        if not target_row or target_row["role"] != "patient" and target != g.user["id"]:
            return err("unknown patient")
        if not can_access(target):
            return err("not allowed", 403)
        if state.snapshot().get("active_session"):
            return err("a session is already running", 409)
        now = time.time()
        cur = g.db.execute("INSERT INTO sessions(user_id,start_ts) VALUES(?,?)", (target, now))
        g.db.commit()
        act = {"id": cur.lastrowid, "user_id": target, "start_ts": now}
        state.update(active_session=act)
        return jsonify(act), 201

    @app.post("/api/sessions/stop")
    @login_required
    def stop_session():
        act = state.snapshot().get("active_session")
        if not act:
            return err("no session running", 409)
        if not can_access(act["user_id"]):
            return err("not allowed", 403)
        end = time.time()
        g.db.execute("UPDATE sessions SET end_ts=? WHERE id=?", (end, act["id"]))
        g.db.commit()
        state.update(active_session=None)
        s = get_session(act["id"])
        return jsonify(session_id=act["id"], features=metrics_for(s))

    @app.get("/api/sessions")
    @login_required
    def list_sessions():
        uid = request.args.get("user_id", g.user["id"], type=int)
        if not can_access(uid):
            return err("not allowed", 403)
        out = []
        for s in g.db.execute("SELECT * FROM sessions WHERE user_id=? AND end_ts IS NOT NULL "
                              "ORDER BY start_ts DESC", (uid,)).fetchall():
            f = metrics_for(s)
            out.append({"id": s["id"], "start_ts": s["start_ts"], "end_ts": s["end_ts"],
                        "duration_s": f["duration_s"], "strides": f["strides"], "valid": f["valid"]})
        return jsonify(out)

    @app.get("/api/sessions/<int:sid>/summary")
    @login_required
    def summary(sid):
        s = get_session(sid)
        if not s or s["end_ts"] is None:
            return err("session not found", 404)
        return jsonify(analytics.compare(g.db, s["user_id"], sid, metrics_for(s), profile_of(s["user_id"])))

    @app.get("/api/sessions/<int:sid>/report.pdf")
    @login_required
    def report_pdf(sid):
        s = get_session(sid)
        if not s or s["end_ts"] is None:
            return err("session not found", 404)
        user = g.db.execute("SELECT * FROM users WHERE id=?", (s["user_id"],)).fetchone()
        prof = profile_of(s["user_id"])
        summ = analytics.compare(g.db, s["user_id"], sid, metrics_for(s), prof)
        pdf = report.build_pdf(g.db, user, prof, dict(s), summ)
        return send_file(io.BytesIO(pdf), mimetype="application/pdf", as_attachment=True,
                         download_name=f"kneetrack_report_{user['username']}_{sid}.pdf")

    @app.get("/api/trend")
    @login_required
    def trend():
        uid = request.args.get("user_id", g.user["id"], type=int)
        if not can_access(uid):
            return err("not allowed", 403)
        out = []
        for s in g.db.execute("SELECT * FROM sessions WHERE user_id=? AND end_ts IS NOT NULL "
                              "ORDER BY start_ts", (uid,)).fetchall():
            f = metrics_for(s)
            if f["valid"]:
                out.append({"id": s["id"], "start_ts": s["start_ts"],
                            **{k: f[k] for k in analytics.FEATURES}})
        return jsonify(out)

    # ---------------- live ----------------
    def live_payload(ids):
        snap = state.snapshot()
        out = {"ble": snap["ble_connected"], "serial": snap["serial_ok"], "hazard": snap["hazard"],
               "gas_level": (snap["env"] or {}).get("gas_level"), "env_stale": snap["env_stale"],
               "active_session": None}
        act = snap.get("active_session")
        if act and (ids is None or act["user_id"] in ids):
            tel = snap["telemetry"] or {}
            out.update(active_session=act, gait=snap["gait"], faults=snap["faults"],
                       telemetry={k: tel.get(k) for k in
                                  ("angle", "gyro", "clearance_mm", "stance", "seq")})
        return out

    @app.get("/api/live")
    @login_required
    def live_http():
        return jsonify(live_payload(accessible_ids(g.db, g.user)))

    @sock.route("/ws/live")
    def live_ws(ws):
        uid = session.get("uid")
        if not uid:
            ws.close()
            return
        conn = db.connect()
        try:
            u = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
            ids = accessible_ids(conn, u) if u else set()
        finally:
            conn.close()
        try:
            while True:
                ws.send(json.dumps(live_payload(ids)))
                time.sleep(config.WS_PUSH_INTERVAL_S)
        except Exception:      # client went away
            return

    # ---------------- frontend (built React app, added in the next step) ----------------
    @app.get("/")
    def index():
        if os.path.exists(os.path.join(STATIC_DIR, "index.html")):
            return send_from_directory(STATIC_DIR, "index.html")
        return jsonify(message="KneeTrack API is running. Frontend not installed yet.")

    @app.get("/<path:path>")
    def assets(path):
        if path.startswith("api/") or not os.path.exists(os.path.join(STATIC_DIR, path)):
            return err("not found", 404)
        return send_from_directory(STATIC_DIR, path)

    return app
