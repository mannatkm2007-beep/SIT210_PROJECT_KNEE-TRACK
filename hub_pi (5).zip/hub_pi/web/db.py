"""Database helpers for the web layer (users, profiles, sessions)."""
import os
import secrets
import sqlite3
import time

from werkzeug.security import generate_password_hash

import config
from db_writer import SCHEMA as CORE_SCHEMA

WEB_SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('patient','physio','admin')), created REAL);
CREATE TABLE IF NOT EXISTS profiles(
  user_id INTEGER PRIMARY KEY, full_name TEXT, age INTEGER, sex TEXT,
  height_cm REAL, weight_kg REAL);
CREATE TABLE IF NOT EXISTS assignments(
  physio_id INTEGER, patient_id INTEGER, PRIMARY KEY(physio_id, patient_id));
CREATE TABLE IF NOT EXISTS sessions(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, start_ts REAL NOT NULL, end_ts REAL, notes TEXT);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id, start_ts);
CREATE TABLE IF NOT EXISTS session_metrics(session_id INTEGER PRIMARY KEY, json TEXT);
"""


def connect():
    os.makedirs(os.path.dirname(config.DB_PATH), exist_ok=True)
    conn = sqlite3.connect(config.DB_PATH, timeout=5)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_db():
    """Create tables, close sessions left open by a crash, create the first admin.
    Returns the generated admin password if an admin was created, else None."""
    conn = connect()
    conn.executescript(CORE_SCHEMA + WEB_SCHEMA)
    conn.execute(
        "UPDATE sessions SET end_ts = COALESCE("
        "(SELECT MAX(ts) FROM telemetry WHERE ts >= sessions.start_ts), start_ts) "
        "WHERE end_ts IS NULL")
    pw = None
    if conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        pw = os.environ.get("KNEETRACK_ADMIN_PASSWORD") or secrets.token_urlsafe(9)
        conn.execute("INSERT INTO users(username,password_hash,role,created) VALUES(?,?,?,?)",
                     ("admin", generate_password_hash(pw), "admin", time.time()))
        conn.execute("INSERT INTO profiles(user_id,full_name) VALUES(1,'Administrator')")
    conn.commit()
    conn.close()
    return pw
