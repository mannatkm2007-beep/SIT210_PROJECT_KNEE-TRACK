"""PDF session report (reportlab + matplotlib)."""
import io
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from reportlab.lib import colors  # noqa: E402
from reportlab.lib.pagesizes import A4  # noqa: E402
from reportlab.lib.styles import getSampleStyleSheet  # noqa: E402
from reportlab.lib.units import cm  # noqa: E402
from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle  # noqa: E402

COLORS = {"green": colors.HexColor("#c8e6c9"), "amber": colors.HexColor("#ffe0b2"),
          "red": colors.HexColor("#ffcdd2")}
LABELS = {"cadence": ("Cadence", "steps/min"), "stance_pct": ("Stance phase", "% of cycle"),
          "rom": ("Shank angle range", "deg"),
          "peak_gyro": ("Peak shank velocity", "deg/s"),
          "clearance_mm": ("Foot clearance", "mm")}


def _chart(conn, start, end):
    mid = (start + end) / 2.0
    rows = conn.execute("SELECT ts,angle,clearance_mm FROM telemetry WHERE ts BETWEEN ? AND ? ORDER BY ts",
                        (mid - 7.5, mid + 7.5)).fetchall()
    if len(rows) < 10:
        return None
    t0 = rows[0]["ts"]
    t = [r["ts"] - t0 for r in rows]
    fig, ax = plt.subplots(2, 1, figsize=(7, 3.6), sharex=True)
    ax[0].plot(t, [r["angle"] for r in rows], lw=1)
    ax[0].set_ylabel("Shank angle (deg)")
    ax[1].plot(t, [r["clearance_mm"] for r in rows], lw=1, color="tab:orange")
    ax[1].set_ylabel("Foot clearance (mm)")
    ax[1].set_xlabel("Time (s)")
    fig.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=130)
    plt.close(fig)
    buf.seek(0)
    return buf


def build_pdf(conn, user, profile, session, summary):
    styles = getSampleStyleSheet()
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm,
                            topMargin=1.8 * cm, bottomMargin=1.8 * cm)
    el = [Paragraph("KneeTrack Session Report", styles["Title"])]
    h, w = profile.get("height_cm"), profile.get("weight_kg")
    bmi = f"{w / ((h / 100) ** 2):.1f}" if h and w else "-"
    info = [["Name", profile.get("full_name") or user["username"], "Age / sex",
             f"{profile.get('age') or '-'} / {profile.get('sex') or '-'}"],
            ["Height / weight", f"{h or '-'} cm / {w or '-'} kg", "BMI", bmi],
            ["Session", time.strftime("%d %b %Y %H:%M", time.localtime(session["start_ts"])),
             "Duration", f"{summary['features']['duration_s']} s"],
            ["Strides detected", str(summary["features"]["strides"]), "Sensor fault time",
             f"{summary['features'].get('fault_pct', 0)}%"]]
    t = Table(info, colWidths=[3.2 * cm, 5.3 * cm, 3.2 * cm, 5.3 * cm])
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
                           ("FONTSIZE", (0, 0), (-1, -1), 9)]))
    el += [t, Spacer(1, 10)]

    f = summary["features"]
    if not f.get("valid"):
        el.append(Paragraph("Not enough walking was recorded (fewer than 10 strides), so no "
                            "results can be reported for this session.", styles["Normal"]))
    else:
        lit, per = summary["literature"]["features"], summary["personal"]
        rows = [["Measure", "Value", "Literature range", "Vs literature", "Vs your baseline"]]
        style = [("GRID", (0, 0), (-1, -1), 0.4, colors.grey), ("FONTSIZE", (0, 0), (-1, -1), 8),
                 ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey)]
        for i, name in enumerate(LABELS, start=1):
            label, unit = LABELS[name]
            l = lit.get(name)
            p = per["features"].get(name)
            rows.append([f"{label} ({unit})", f"{f[name]}",
                         f"{l['band'][0]:.0f} to {l['band'][1]:.0f}" if l and "band" in l else "n/a",
                         l["status"] if l else "n/a",
                         (f"{p['status']} (z={p['z']})" if p else per["state"])])
            if l and l.get("status") in COLORS:
                style.append(("BACKGROUND", (3, i), (3, i), COLORS[l["status"]]))
            if p:
                style.append(("BACKGROUND", (4, i), (4, i), COLORS[p["status"]]))
        t = Table(rows, colWidths=[5.2 * cm, 1.8 * cm, 3 * cm, 2.6 * cm, 4.4 * cm])
        t.setStyle(TableStyle(style))
        el += [Paragraph("Results", styles["Heading2"]), t, Spacer(1, 8)]
        g = f["gait_pct"]
        el.append(Paragraph(
            f"Gait classes: normal {g['normal']}%, mild deviation {g['mild']}%, significant "
            f"deviation {g['significant']}%. Significant-deviation episodes: "
            f"{f['significant_episodes']}.", styles["Normal"]))
        img = _chart(conn, session["start_ts"], session["end_ts"])
        if img:
            el += [Spacer(1, 8), Image(img, width=16 * cm, height=8.2 * cm)]

    ev = conn.execute("SELECT kind, COUNT(*) c FROM events WHERE ts BETWEEN ? AND ? GROUP BY kind",
                      (session["start_ts"], session["end_ts"])).fetchall()
    if ev:
        el += [Spacer(1, 8), Paragraph("Events during session: " +
               ", ".join(f"{e['kind']} x{e['c']}" for e in ev), styles["Normal"])]
    el += [Spacer(1, 14), Paragraph(
        "Notes and limitations: this report is for monitoring and is not a medical diagnosis. "
        "Literature ranges are provisional values from published studies and are not measured norms "
        "for this device. The sensor measures shank tilt, which is a proxy for knee motion. "
        "Comparison with your baseline uses your first three valid sessions.", styles["Italic"])]
    doc.build(el)
    return buf.getvalue()
