"""Per-session gait features, literature bands and personal-baseline comparison."""
import json
import math

FEATURES = ["cadence", "stance_pct", "rom", "peak_gyro", "clearance_mm"]
FLAG_STANCE = 16

# Provisional literature-derived bands (see report). NOT measured norms for this hardware.
LIT_BANDS = {
    "cadence": {"adult": (100.0, 120.0), "older": (100.0, 115.0)},   # steps/min
    "stance_pct": {"adult": (58.0, 65.0), "older": (58.0, 65.0)},    # % of gait cycle
}
BASELINE_SESSIONS = 3
Z_AMBER, Z_RED = 1.5, 2.5


def _mean(x):
    return sum(x) / len(x) if x else None


def _sd(x):
    if len(x) < 2:
        return 0.0
    m = _mean(x)
    return math.sqrt(sum((v - m) ** 2 for v in x) / (len(x) - 1))


def extract_strides(rows):
    """rows: (ts, angle, gyro, clearance_mm, flags) sorted by ts. A stride runs from one
    stance start to the next. Returns a list of per-stride feature dicts."""
    strides, r0, f0, prev = [], None, None, 0
    for i, (ts, _a, _g, _c, flags) in enumerate(rows):
        st = 1 if flags & FLAG_STANCE else 0
        if st and not prev:                      # stance start
            if r0 is not None and f0 is not None:
                dur = ts - rows[r0][0]
                sdur = rows[f0][0] - rows[r0][0]
                if 0.6 <= dur <= 2.5 and 0 < sdur < dur:
                    seg = rows[r0:i + 1]
                    angs = [s[1] for s in seg]
                    strides.append({
                        "dur": dur,
                        "stance_pct": 100.0 * sdur / dur,
                        "rom": max(angs) - min(angs),
                        "peak_gyro": max(abs(s[2]) for s in seg),
                        "clearance_mm": max(s[3] for s in seg),
                    })
            r0, f0 = i, None
        elif prev and not st and r0 is not None and f0 is None:
            f0 = i                                # stance end
        prev = st
    return strides


def session_features(conn, start, end):
    rows = [tuple(r) for r in conn.execute(
        "SELECT ts,angle,gyro,clearance_mm,flags,gait FROM telemetry "
        "WHERE ts>=? AND ts<=? ORDER BY ts", (start, end))]
    out = {"duration_s": round(max(0.0, end - start), 1), "samples": len(rows),
           "strides": 0, "valid": False}
    if not rows:
        return out
    strides = extract_strides([r[:5] for r in rows])
    n = len(rows)
    gaits = [r[5] for r in rows]
    out["gait_pct"] = {k: round(100.0 * gaits.count(v) / n, 1)
                       for k, v in (("normal", 0), ("mild", 1), ("significant", 2))}
    out["significant_episodes"] = (1 if gaits[0] == 2 else 0) + sum(
        1 for i in range(1, n) if gaits[i] == 2 and gaits[i - 1] != 2)
    out["fault_pct"] = round(100.0 * sum(1 for r in rows if r[4] & 7) / n, 1)
    out["strides"] = len(strides)
    if len(strides) >= 10:
        out["valid"] = True
        out["cadence"] = round(120.0 / _mean([s["dur"] for s in strides]), 1)
        out["stance_pct"] = round(_mean([s["stance_pct"] for s in strides]), 1)
        out["rom"] = round(_mean([s["rom"] for s in strides]), 1)
        out["peak_gyro"] = round(_mean([s["peak_gyro"] for s in strides]), 1)
        out["clearance_mm"] = round(_mean([s["clearance_mm"] for s in strides]), 1)
    return out


def literature_status(features, profile):
    group = "older" if (profile.get("age") or 0) > 60 else "adult"
    res = {"group": "age over 60" if group == "older" else "age 60 or under", "features": {}}
    for name, bands in LIT_BANDS.items():
        v = features.get(name)
        if v is None:
            res["features"][name] = {"status": "insufficient data"}
            continue
        lo, hi = bands[group]
        margin = 0.1 * (lo + hi) / 2.0
        if lo <= v <= hi:
            status = "green"
        elif lo - margin <= v <= hi + margin:
            status = "amber"
        else:
            status = "red"
        res["features"][name] = {"value": v, "band": [lo, hi], "status": status}
    return res


def _z_status(z):
    a = abs(z)
    return "green" if a <= Z_AMBER else ("amber" if a <= Z_RED else "red")


def personal_status(conn, user_id, session_id, features):
    rows = conn.execute(
        "SELECT s.id, m.json FROM sessions s JOIN session_metrics m ON m.session_id=s.id "
        "WHERE s.user_id=? AND s.end_ts IS NOT NULL ORDER BY s.start_ts", (user_id,)).fetchall()
    valid = [(r["id"], json.loads(r["json"])) for r in rows]
    valid = [(i, f) for i, f in valid if f.get("valid")]
    base = valid[:BASELINE_SESSIONS]
    base_ids = [i for i, _ in base]
    res = {"baseline_sessions": len(base), "needed": BASELINE_SESSIONS, "features": {}}
    if not features.get("valid"):
        res["state"] = "insufficient data"
        return res
    if session_id in base_ids or len(base) < BASELINE_SESSIONS:
        res["state"] = "collecting baseline"
        return res
    res["state"] = "compared"
    for name in FEATURES:
        vals = [f[name] for _, f in base if name in f]
        v = features.get(name)
        if v is None or len(vals) < 2:
            continue
        m = _mean(vals)
        sd = max(_sd(vals), 0.05 * abs(m), 1e-6)     # floor: 3 sessions give a shaky SD
        z = (v - m) / sd
        res["features"][name] = {"value": v, "mean": round(m, 1), "sd": round(sd, 2),
                                 "z": round(z, 2), "status": _z_status(z)}
    return res


def compare(conn, user_id, session_id, features, profile):
    return {"features": features,
            "literature": literature_status(features, profile),
            "personal": personal_status(conn, user_id, session_id, features)}
