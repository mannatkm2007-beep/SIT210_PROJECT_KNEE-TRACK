"""USB serial listener for the base station's 1 Hz JSON."""
import glob
import itertools
import json
import logging
import threading
import time

import serial

import config

log = logging.getLogger("serial")
_tie = itertools.count()


def find_port():
    if config.SERIAL_PORT != "auto":
        return config.SERIAL_PORT
    ports = sorted(glob.glob("/dev/ttyACM*") + glob.glob("/dev/ttyUSB*"))
    return ports[0] if ports else None


class SerialListener(threading.Thread):
    def __init__(self, db_q, alert_q, state, stop_evt):
        super().__init__(name="serial-listener", daemon=True)
        self.db_q, self.alert_q, self.state, self.stop_evt = db_q, alert_q, state, stop_evt
        self.ok = None

    def _set_ok(self, flag):
        if flag == self.ok:
            return
        self.ok = flag
        self.state.update(serial_ok=flag)
        self.alert_q.put((0, next(_tie), {"type": "serial", "ok": flag, "ts": time.time()}))
        log.info("serial %s", "ok" if flag else "lost")

    def _process_line(self, line):
        try:
            obj = json.loads(line.decode("utf-8", errors="ignore").strip())
            gas, hazard = int(obj["gas_level"]), int(obj["hazard"])
            if hazard not in (0, 1):
                raise ValueError("hazard must be 0 or 1")
        except (ValueError, KeyError, TypeError):
            log.debug("bad serial line: %r", line)
            return
        rec = {"ts": time.time(), "gas_level": gas, "hazard": hazard}
        self.db_q.put(("env", rec))
        self.alert_q.put((0, next(_tie), {"type": "env", **rec}))

    def run(self):
        while not self.stop_evt.is_set():
            port = find_port()
            if port is None:
                self._set_ok(False)
                time.sleep(config.SERIAL_RETRY_S)
                continue
            try:
                with serial.Serial(port, config.SERIAL_BAUD, timeout=1) as ser:
                    self._set_ok(True)
                    while not self.stop_evt.is_set():
                        line = ser.readline()
                        if line:
                            self._process_line(line)
            except (serial.SerialException, OSError) as exc:
                log.warning("serial error: %s", exc)
            self._set_ok(False)
            time.sleep(config.SERIAL_RETRY_S)
