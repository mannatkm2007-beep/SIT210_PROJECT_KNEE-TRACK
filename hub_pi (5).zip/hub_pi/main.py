"""KneeTrack hub entry point (Phase 4: BLE, serial, database, alerts)."""
import logging
import os
import queue
import signal
import socket
import threading
import time

from alert_processor import AlertProcessor
from ble_receiver import BleReceiver
from db_writer import DbWriter
from serial_listener import SerialListener
from state import State
from web.server import WebServer


def sd_notify(msg):
    """Tell systemd we are ready / alive (no extra package needed)."""
    addr = os.environ.get("NOTIFY_SOCKET")
    if not addr:
        return
    if addr.startswith("@"):
        addr = "\0" + addr[1:]
    s = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
    try:
        s.connect(addr)
        s.sendall(msg.encode())
    except OSError:
        pass
    finally:
        s.close()


def main():
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    log = logging.getLogger("main")

    stop_evt = threading.Event()
    db_q = queue.Queue()
    alert_q = queue.PriorityQueue()
    state = State()

    threads = [
        DbWriter(db_q, stop_evt),
        AlertProcessor(alert_q, db_q, state, stop_evt),
        SerialListener(db_q, alert_q, state, stop_evt),
        BleReceiver(db_q, alert_q, state, stop_evt),
        WebServer(state, stop_evt),
    ]
    for t in threads:
        t.start()

    def shutdown(*_):
        log.info("shutting down")
        stop_evt.set()

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    sd_notify("READY=1")
    log.info("KneeTrack hub running")
    while not stop_evt.is_set():
        if all(t.is_alive() for t in threads):
            sd_notify("WATCHDOG=1")      # if a thread dies we stop pinging; systemd restarts us
        else:
            dead = [t.name for t in threads if not t.is_alive()]
            log.error("thread(s) died: %s", dead)
        time.sleep(2)

    for t in threads:
        t.join(timeout=3)


if __name__ == "__main__":
    main()
