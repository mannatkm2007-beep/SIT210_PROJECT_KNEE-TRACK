"""Generate FAKE labelled walking CSVs to test the Colab pipeline before the wearable exists.
The data is synthetic. Never use it for real results or in the report.

  python3 tools/make_fake_data.py --out ~/fake_csv --subjects 5
Upload the files to Drive KneeTrack/raw/ to test the notebook. Before real data, DELETE them from
raw/ and also empty KneeTrack/clean/ and KneeTrack/models/.
"""
import argparse
import csv
import os

import numpy as np

PARAMS = {"normal": dict(rom=55, stride=1.10, clr=40), "mild": dict(rom=40, stride=1.25, clr=25),
          "significant": dict(rom=28, stride=1.50, clr=10)}
COLS = ["ts", "dev_ms", "angle", "gyro", "fsr", "clearance_mm", "acc_mg", "gait", "flags", "seq", "replay",
        "label", "subject", "age", "sex", "height_cm", "weight_kg"]


def walk(rng, label, secs, base):
    p = PARAMS[label]
    n = int(secs * 50)
    t = np.arange(n) / 50.0
    ph = (t % p["stride"]) / p["stride"]
    stance = ph < 0.6
    angle = (p["rom"] / 2) * np.sin(2 * np.pi * ph) + rng.normal(0, 0.5, n)
    gyro = p["rom"] * np.pi * np.cos(2 * np.pi * ph) / p["stride"] + rng.normal(0, 3, n)
    fsr = np.clip(np.where(stance, 400, 5) + rng.normal(0, 8, n), 0, 1023)
    clr = np.clip(np.where(stance, 0, p["clr"] * np.sin(np.pi * np.clip((ph - 0.6) / 0.4, 0, 1))) + rng.normal(0, 1, n), 0, None)
    acc = 1000 + rng.normal(0, 30, n)
    flags = np.where(stance, 16, 0)
    return [(base + t[i] + rng.normal(0, 0.015), int(t[i] * 1000), angle[i], gyro[i], fsr[i], clr[i], acc[i],
             0, int(flags[i]), i % 256, 0) for i in range(n)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.expanduser("~/fake_csv"))
    ap.add_argument("--subjects", type=int, default=5)
    ap.add_argument("--walks", type=int, default=2, help="walks per class per subject")
    ap.add_argument("--seconds", type=int, default=60)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    rng = np.random.default_rng(7)
    ages, sexes = [25, 31, 52, 67, 29, 44, 38, 58], ["male", "female"]
    for s in range(a.subjects):
        sid = f"F{s + 1:02d}"
        age, sex = ages[s % len(ages)], sexes[s % 2]
        for label in PARAMS:
            for w in range(a.walks):
                rows = walk(rng, label, a.seconds, 1.7e9 + s * 1e4 + w * 1e3)
                path = os.path.join(a.out, f"FAKE_{sid}_{label}_{w}.csv")
                with open(path, "w", newline="") as fh:
                    wr = csv.writer(fh)
                    wr.writerow(COLS)
                    for r in rows:
                        wr.writerow(list(r) + [label, sid, age, sex, 170, 65])
    print(f"wrote {a.subjects * 3 * a.walks} FAKE files to {a.out}")


if __name__ == "__main__":
    main()
