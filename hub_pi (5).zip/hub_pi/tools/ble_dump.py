"""Step-1 test: connect to the wearable and print decoded packets. No database needed.
Run from hub_pi/:  python3 tools/ble_dump.py
"""
import asyncio
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from bleak import BleakClient, BleakScanner  # noqa: E402

import config  # noqa: E402
import packets  # noqa: E402


def on_data(_s, data):
    p = packets.decode(data)
    if p is None:
        print("bad packet length", len(data))
        return
    print(f"seq={p['seq']:3d} angle={p['angle']:7.2f} "
          f"clr={p['clearance_mm']:4d}mm stance={p['stance']} gait={p['gait']} flags={p['flags']:#04x}")


async def main():
    print("scanning for", config.DEVICE_NAME)
    dev = await BleakScanner.find_device_by_name(config.DEVICE_NAME, timeout=10)
    if dev is None:
        print("not found")
        return
    async with BleakClient(dev) as client:
        await client.start_notify(config.CHAR_UUID, on_data)
        await asyncio.sleep(30)


asyncio.run(main())
