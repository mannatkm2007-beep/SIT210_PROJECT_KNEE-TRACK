"""Export a labelled walk from the Pi database to CSV (light job: one SELECT).
Copy the CSV to Google Drive: KneeTrack/raw/

Examples (run from hub_pi/):
  python3 tools/export_csv.py --label normal --subject S01 --age 28 --sex male --height 175 --weight 70 --last 90
  python3 tools/export_csv.py --label mild --subject S01 --session 12
Use subject IDs, not names. Labels: normal, mild, significant (deviations are simulated by volunteers).
"""
import argparse
import csv
import os
import re
import sqlite3
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import config  # noqa: E402

COLS = ["ts", "dev_ms", "angle", "gyro", "fsr", "clearance_mm", "acc_mg", "gait", "flags", "seq", "replay"]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--label", required=True, choices=["normal", "mild", "significant"])
    ap.add_argument("--subject", required=True, help="anonymous ID, e.g. S01")
    ap.add_argument("--age", type=int)
    ap.add_argument("--sex", choices=["male", "female", "other"])
    ap.add_argument("--height", type=float, help="cm")
    ap.add_argument("--weight", type=float, help="kg")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--last", type=float, help="export the last N seconds")
    g.add_argument("--session", type=int, help="export a dashboard session by id")
    g.add_argument("--start", type=float, help="start (unix time); use with --end")
    ap.add_argument("--end", type=float)
    ap.add_argument("--out", default=os.path.expanduser("~/kneetrack_data/export"))
    a = ap.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,20}", a.subject):
        sys.exit("subject must be 1 to 20 letters, digits, - or _")

    conn = sqlite3.connect(config.DB_PATH)
    if a.last:
        end = time.time()
        start = end - a.last
    elif a.session:
        r = conn.execute("SELECT start_ts, end_ts FROM sessions WHERE id=?", (a.session,)).fetchone()
        if not r or r[1] is None:
            sys.exit("session not found or still running")
        start, end = r
    else:
        if a.end is None:
            sys.exit("--start needs --end")
        start, end = a.start, a.end
    rows = conn.execute(f"SELECT {','.join(COLS)} FROM telemetry WHERE ts BETWEEN ? AND ? ORDER BY ts",
                        (start, end)).fetchall()
    conn.close()
    if not rows:
        sys.exit("no telemetry in that time range")
    os.makedirs(a.out, exist_ok=True)
    path = os.path.join(a.out, f"{a.subject}_{a.label}_{time.strftime('%Y%m%d_%H%M%S')}.csv")
    meta = [a.label, a.subject, a.age or "", a.sex or "", a.height or "", a.weight or ""]
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(COLS + ["label", "subject", "age", "sex", "height_cm", "weight_kg"])
        for r in rows:
            w.writerow(list(r) + meta)
    print(f"{len(rows)} rows ({len(rows) / 50:.0f} s at 50 Hz) -> {path}")
    if len(rows) < 1500:
        print("WARNING: under 30 s of data. Aim for 60 to 90 s of continuous walking per file.")


if __name__ == "__main__":
    main()
