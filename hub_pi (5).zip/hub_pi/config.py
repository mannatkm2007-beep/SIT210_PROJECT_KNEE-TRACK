"""KneeTrack hub configuration. Edit values here."""
import os

# --- BLE (must match the wearable firmware) ---
DEVICE_NAME = "KneeTrack"
SERVICE_UUID = "a7c10000-5d3e-4f6a-9b1c-2e8f4d6a1b00"
CHAR_UUID = "a7c10001-5d3e-4f6a-9b1c-2e8f4d6a1b00"
SCAN_TIMEOUT_S = 5.0
HEARTBEAT_TIMEOUT_S = 2.0     # no packet for this long => treat link as dead, reconnect
RECONNECT_DELAY_S = 1.0

# --- USB serial from the base station (Arduino Uno) ---
SERIAL_PORT = "auto"          # "auto" = first /dev/ttyACM* or /dev/ttyUSB*, or set e.g. "/dev/ttyACM0"
SERIAL_BAUD = 115200
SERIAL_RETRY_S = 2.0
ENV_STALE_S = 5.0             # no base-station packet for this long => mark stale

# --- Database ---
DB_PATH = os.environ.get("KNEETRACK_DB", os.path.expanduser("~/kneetrack_data/kneetrack.db"))
DB_COMMIT_INTERVAL_S = 0.5
DB_BATCH_MAX = 100

# --- Web dashboard / API ---
WEB_HOST = "0.0.0.0"
WEB_PORT = 5000
WS_PUSH_INTERVAL_S = 0.2
LOGIN_MAX_FAILS = 5
LOGIN_LOCK_S = 60
