"""SQLite (WAL) writer thread. Single consumer of db_q, batches commits."""
import logging
import os
import queue
import sqlite3
import threading
import time

import config

log = logging.getLogger("db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS telemetry(
  id INTEGER PRIMARY KEY, ts REAL, dev_ms INTEGER, angle REAL, gyro REAL, fsr INTEGER,
  clearance_mm INTEGER, acc_mg INTEGER, gait INTEGER, flags INTEGER, seq INTEGER, replay INTEGER);
CREATE TABLE IF NOT EXISTS env(
  id INTEGER PRIMARY KEY, ts REAL, gas_level INTEGER, hazard INTEGER);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY, ts REAL, kind TEXT, detail TEXT);
CREATE INDEX IF NOT EXISTS idx_tel_ts ON telemetry(ts);
CREATE INDEX IF NOT EXISTS idx_env_ts ON env(ts);
CREATE INDEX IF NOT EXISTS idx_evt_ts ON events(ts);
"""


def open_db(path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path, timeout=5)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.executescript(SCHEMA)
    ok = conn.execute("PRAGMA integrity_check").fetchone()[0]
    log.info("database %s, integrity_check=%s", path, ok)
    return conn


def _write(conn, batch):
    for kind, d in batch:
        if kind == "telemetry":
            conn.execute(
                "INSERT INTO telemetry(ts,dev_ms,angle,gyro,fsr,clearance_mm,acc_mg,gait,flags,seq,replay)"
                " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (d["ts"], d["dev_ms"], d["angle"], d["gyro"], d["fsr"], d["clearance_mm"],
                 d["acc_mg"], d["gait"], d["flags"], d["seq"], d["replay"]))
        elif kind == "env":
            conn.execute("INSERT INTO env(ts,gas_level,hazard) VALUES(?,?,?)",
                         (d["ts"], d["gas_level"], d["hazard"]))
        elif kind == "event":
            conn.execute("INSERT INTO events(ts,kind,detail) VALUES(?,?,?)",
                         (d["ts"], d["kind"], d["detail"]))
    conn.commit()


class DbWriter(threading.Thread):
    def __init__(self, db_q, stop_evt):
        super().__init__(name="db-writer", daemon=True)
        self.db_q, self.stop_evt = db_q, stop_evt

    def run(self):
        conn = open_db(config.DB_PATH)
        batch, last_commit = [], time.monotonic()
        while not (self.stop_evt.is_set() and self.db_q.empty() and not batch):
            try:
                batch.append(self.db_q.get(timeout=0.2))
            except queue.Empty:
                pass
            due = time.monotonic() - last_commit >= config.DB_COMMIT_INTERVAL_S
            if batch and (due or len(batch) >= config.DB_BATCH_MAX or self.stop_evt.is_set()):
                try:
                    _write(conn, batch)
                    batch = []
                except sqlite3.Error as exc:
                    log.error("db write failed (%s), retrying", exc)
                    time.sleep(0.5)
                last_commit = time.monotonic()
        conn.close()
