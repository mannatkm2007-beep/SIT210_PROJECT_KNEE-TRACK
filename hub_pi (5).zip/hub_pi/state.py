"""Thread-safe shared state (the dashboard reads this in Phase 5)."""
import threading


class State:
    def __init__(self):
        self._lock = threading.Lock()
        self._data = {
            "ble_connected": False,
            "telemetry": None,
            "telemetry_ts": None,
            "env": None,
            "env_ts": None,
            "env_stale": True,
            "serial_ok": False,
            "hazard": 0,
            "active_session": None,
            "gait": 0,
            "faults": {"ultrasonic": False, "imu": False},
        }

    def update(self, **kwargs):
        with self._lock:
            self._data.update(kwargs)

    def snapshot(self):
        with self._lock:
            return dict(self._data)
