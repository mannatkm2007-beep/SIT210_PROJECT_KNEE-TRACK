"""Alert processor: highest-priority consumer. Turns raw data into state + events."""
import logging
import queue
import threading
import time

import config
import packets

log = logging.getLogger("alerts")


class AlertProcessor(threading.Thread):
    def __init__(self, alert_q, db_q, state, stop_evt):
        super().__init__(name="alert-processor", daemon=True)
        self.alert_q, self.db_q, self.state, self.stop_evt = alert_q, db_q, state, stop_evt
        self.prev_gait = 0
        self.prev_flags = 0
        self.prev_hazard = 0
        self.env_ts = None

    def _event(self, kind, detail=""):
        log.info("EVENT %s %s", kind, detail)
        self.db_q.put(("event", {"ts": time.time(), "kind": kind, "detail": detail}))

    def _telemetry(self, e):
        faults = {
            "ultrasonic": bool(e["flags"] & packets.FLAG_US_FAULT),
            "imu": bool(e["flags"] & packets.FLAG_IMU_FAULT),
        }
        if e["gait"] != self.prev_gait:
            self._event("gait_" + packets.GAIT_NAMES.get(e["gait"], "unknown"))
            self.prev_gait = e["gait"]
        changed = (e["flags"] ^ self.prev_flags) & 0x06     # ultrasonic / IMU faults
        if changed:
            self._event("sensor_fault", ",".join(k for k, v in faults.items() if v) or "all_clear")
            self.prev_flags = e["flags"]
        self.state.update(telemetry=e, telemetry_ts=e["ts"], gait=e["gait"], faults=faults)

    def _env(self, e):
        if e["hazard"] != self.prev_hazard:
            self._event("gas_hazard" if e["hazard"] else "gas_clear", str(e["gas_level"]))
            self.prev_hazard = e["hazard"]
        self.env_ts = time.monotonic()
        self.state.update(env=e, env_ts=e["ts"], env_stale=False, hazard=e["hazard"])

    def run(self):
        while not self.stop_evt.is_set():
            try:
                _prio, _n, e = self.alert_q.get(timeout=1.0)
            except queue.Empty:
                e = None
            if e is not None:
                t = e["type"]
                if t == "telemetry":
                    self._telemetry(e)
                elif t == "env":
                    self._env(e)
                elif t == "ble":
                    self._event("ble_connected" if e["connected"] else "ble_lost")
                elif t == "serial":
                    self._event("serial_ok" if e["ok"] else "serial_lost")
            if self.env_ts and time.monotonic() - self.env_ts > config.ENV_STALE_S:
                self.state.update(env_stale=True)
