"""Decoder for the 17-byte wearable telemetry packet."""
import struct

PACKET_FMT = "<IhhHHHBBB"     # little-endian, packed (matches the Arduino struct)
PACKET_SIZE = struct.calcsize(PACKET_FMT)   # 17

FLAG_FSR_FAULT = 1
FLAG_US_FAULT = 2
FLAG_IMU_FAULT = 4
FLAG_REPLAY = 8
FLAG_STANCE = 16

GAIT_NAMES = {0: "normal", 1: "mild", 2: "significant"}


def decode(data):
    """Return a dict, or None if the packet is the wrong size."""
    if len(data) != PACKET_SIZE:
        return None
    t_ms, ang, gyro, fsr, clr, acc, gait, flags, seq = struct.unpack(PACKET_FMT, bytes(data))
    return {
        "dev_ms": t_ms,
        "angle": ang / 100.0,
        "gyro": gyro / 10.0,
        "fsr": fsr,
        "clearance_mm": clr,
        "acc_mg": acc,
        "gait": gait,
        "flags": flags,
        "seq": seq,
        "replay": 1 if flags & FLAG_REPLAY else 0,
        "stance": 1 if flags & FLAG_STANCE else 0,
    }
