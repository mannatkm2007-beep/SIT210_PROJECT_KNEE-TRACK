"""BLE receiver thread: scans, connects, subscribes, reconnects on heartbeat timeout."""
import asyncio
import itertools
import logging
import threading
import time

from bleak import BleakClient, BleakScanner

import config
import packets

log = logging.getLogger("ble")
_tie = itertools.count()


class BleReceiver(threading.Thread):
    def __init__(self, db_q, alert_q, state, stop_evt):
        super().__init__(name="ble-receiver", daemon=True)
        self.db_q, self.alert_q, self.state, self.stop_evt = db_q, alert_q, state, stop_evt
        self.connected = False
        self.last_rx = time.monotonic()
        self.ref = None   # (wall_time, dev_ms) from the latest live packet

    def run(self):
        asyncio.run(self._main())

    def _set_connected(self, flag):
        if flag == self.connected:
            return
        self.connected = flag
        self.state.update(ble_connected=flag)
        self.alert_q.put((0, next(_tie), {"type": "ble", "connected": flag, "ts": time.time()}))
        log.info("BLE %s", "connected" if flag else "disconnected")

    def _on_data(self, _sender, data):
        self.last_rx = time.monotonic()
        pkt = packets.decode(data)
        if pkt is None:
            return
        now = time.time()
        if pkt["replay"] and self.ref:
            ref_wall, ref_ms = self.ref
            pkt["ts"] = ref_wall - ((ref_ms - pkt["dev_ms"]) & 0xFFFFFFFF) / 1000.0
        else:
            pkt["ts"] = now
            if not pkt["replay"]:
                self.ref = (now, pkt["dev_ms"])
        self.db_q.put(("telemetry", pkt))
        if not pkt["replay"]:      # replayed (old) data must not trigger live alerts
            self.alert_q.put((1, next(_tie), {"type": "telemetry", **pkt}))

    async def _main(self):
        while not self.stop_evt.is_set():
            try:
                dev = await BleakScanner.find_device_by_name(
                    config.DEVICE_NAME, timeout=config.SCAN_TIMEOUT_S)
                if dev is None:
                    continue
                async with BleakClient(dev) as client:
                    self.last_rx = time.monotonic()
                    self._set_connected(True)
                    await client.start_notify(config.CHAR_UUID, self._on_data)
                    while client.is_connected and not self.stop_evt.is_set():
                        await asyncio.sleep(0.25)
                        if time.monotonic() - self.last_rx > config.HEARTBEAT_TIMEOUT_S:
                            log.warning("BLE heartbeat timeout, reconnecting")
                            break
            except Exception as exc:   # keep the thread alive no matter what
                log.warning("BLE error: %s", exc)
            finally:
                self._set_connected(False)
                await asyncio.sleep(config.RECONNECT_DELAY_S)
