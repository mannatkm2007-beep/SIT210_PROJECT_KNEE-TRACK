"""KneeTrack shared preprocessing. Used by the Colab notebook (training) AND the Pi (inference),
so both sides clean and window the data the same way. numpy only."""
import numpy as np

FS = 50                      # samples per second after resampling
WIN = 100                    # window length: 2 s
STEP = 25                    # window hop: 0.5 s
CHANNELS = ["angle", "gyro", "clearance_mm", "acc_mg", "stance"]      # no FSR: stance comes from foot height
LIMITS = {"angle": (-150.0, 150.0), "gyro": (-2000.0, 2000.0),
          "clearance_mm": (0.0, 1000.0), "acc_mg": (0.0, 8000.0)}
FAULT_MASK = 7               # flag bits 2,4 = ultrasonic / IMU fault (bit 1 was the FSR, now unused)
STANCE_BIT = 16
MAX_GAP_S = 0.2              # a bigger hole in the data splits the recording
MIN_SEG_S = 5.0              # shorter pieces are dropped
HAMPEL_CHANNELS = ("angle", "gyro", "clearance_mm", "acc_mg")
STAT_KEYS = ["rows_in", "duplicates", "fault_flag", "out_of_range", "gaps",
             "short_segments_dropped", "spikes_fixed", "rows_kept"]


def hampel(x, k=5, n_sigmas=8.0):
    """Replace isolated spikes with the local median. Returns (cleaned, number_fixed)."""
    x = np.asarray(x, dtype=float)
    if len(x) < 2 * k + 1:
        return x.copy(), 0
    win = np.lib.stride_tricks.sliding_window_view(np.pad(x, k, mode="edge"), 2 * k + 1)
    med = np.median(win, axis=1)
    mad = np.median(np.abs(win - med[:, None]), axis=1) * 1.4826
    floor = 0.10 * np.std(x) + 1e-6
    bad = np.abs(x - med) > n_sigmas * np.maximum(mad, floor)
    y = x.copy()
    y[bad] = med[bad]
    return y, int(bad.sum())


def clean_and_resample(t, cols, flags, trim_s=0.0):
    """t: seconds on the device clock. cols: dict of angle, gyro, clearance_mm, acc_mg.
    Returns (segments, stats). Each segment is an array (n, 6) at exactly FS Hz."""
    stats = dict.fromkeys(STAT_KEYS, 0)
    t = np.asarray(t, float)
    stats["rows_in"] = int(len(t))
    if len(t) == 0:
        return [], stats
    flags = np.asarray(flags).astype(int)
    cols = {k: np.asarray(v, float) for k, v in cols.items()}
    order = np.argsort(t, kind="stable")
    t, flags = t[order], flags[order]
    cols = {k: v[order] for k, v in cols.items()}

    keep = np.concatenate(([True], np.diff(t) > 0))                 # duplicates
    stats["duplicates"] = int((~keep).sum())
    t, flags = t[keep], flags[keep]
    cols = {k: v[keep] for k, v in cols.items()}

    no_fault = (flags & FAULT_MASK) == 0                            # sensor-fault rows
    stats["fault_flag"] = int((~no_fault).sum())
    in_range = np.ones(len(t), bool)
    for name, (lo, hi) in LIMITS.items():
        v = cols[name]
        in_range &= np.isfinite(v) & (v >= lo) & (v <= hi)
    stats["out_of_range"] = int((no_fault & ~in_range).sum())
    ok = no_fault & in_range
    t, flags = t[ok], flags[ok]
    cols = {k: v[ok] for k, v in cols.items()}
    if len(t) < 2:
        return [], stats

    cuts = np.flatnonzero(np.diff(t) > MAX_GAP_S) + 1               # gaps -> separate segments
    stats["gaps"] = int(len(cuts))
    bounds = np.concatenate(([0], cuts, [len(t)]))
    stance_raw = ((flags & STANCE_BIT) > 0).astype(float)
    segments = []
    for a, b in zip(bounds[:-1], bounds[1:]):
        if b - a < 2 or t[b - 1] - t[a] < MIN_SEG_S + 2 * trim_s:
            stats["short_segments_dropped"] += 1
            continue
        grid = np.arange(t[a] + trim_s, t[b - 1] - trim_s, 1.0 / FS)
        out = []
        for name in CHANNELS[:-1]:
            y = np.interp(grid, t[a:b], cols[name][a:b])
            if name in HAMPEL_CHANNELS:
                y, fixed = hampel(y)
                stats["spikes_fixed"] += fixed
            out.append(y)
        out.append((np.interp(grid, t[a:b], stance_raw[a:b]) >= 0.5).astype(float))
        seg = np.stack(out, axis=1)
        segments.append(seg)
        stats["rows_kept"] += len(seg)
    return segments, stats


def prepare_rows(ts, dev_ms, cols, flags, trim_s=0.0):
    """Entry point for database/CSV rows. Orders by arrival time, splits where the wearable
    rebooted (device clock went back), then cleans each piece on the device clock."""
    ts = np.asarray(ts, float)
    dev_ms = np.asarray(dev_ms, float)
    order = np.argsort(ts, kind="stable")
    ts, dev_ms = ts[order], dev_ms[order]
    flags = np.asarray(flags)[order]
    cols = {k: np.asarray(v)[order] for k, v in cols.items()}
    epoch = np.concatenate(([0], np.cumsum(np.diff(dev_ms) < -5000))) if len(ts) else np.array([])
    segments, total = [], dict.fromkeys(STAT_KEYS, 0)
    for e in np.unique(epoch):
        m = epoch == e
        segs, st = clean_and_resample(dev_ms[m] / 1000.0, {k: v[m] for k, v in cols.items()},
                                      flags[m], trim_s)
        segments += segs
        for k in STAT_KEYS:
            total[k] += st[k]
    return segments, total


def make_windows(seg, win=WIN, step=STEP):
    """(n, channels) -> (n_windows, channels, win) float32."""
    n = len(seg)
    if n < win:
        return np.zeros((0, seg.shape[1], win), np.float32)
    idx = range(0, n - win + 1, step)
    return np.stack([seg[i:i + win].T for i in idx]).astype(np.float32)


def compute_norm(windows):
    mean = windows.mean(axis=(0, 2))
    std = windows.std(axis=(0, 2)) + 1e-6
    return mean, std


def normalise(windows, mean, std):
    mean, std = np.asarray(mean, np.float32), np.asarray(std, np.float32)
    return ((windows - mean[None, :, None]) / std[None, :, None]).astype(np.float32)


def stride_features(seg):
    """Walking features from one resampled segment (same definitions as the dashboard).
    Returns None when fewer than 10 valid strides."""
    st = seg[:, CHANNELS.index("stance")] > 0.5
    ang, gyro = seg[:, CHANNELS.index("angle")], seg[:, CHANNELS.index("gyro")]
    clr = seg[:, CHANNELS.index("clearance_mm")]
    rises = np.flatnonzero(st[1:] & ~st[:-1]) + 1
    falls = np.flatnonzero(~st[1:] & st[:-1]) + 1
    rows = []
    for a, b in zip(rises[:-1], rises[1:]):
        dur = (b - a) / FS
        f = falls[(falls > a) & (falls < b)]
        if len(f) == 0 or not (0.6 <= dur <= 2.5):
            continue
        sdur = (f[0] - a) / FS
        rows.append((dur, 100.0 * sdur / dur, ang[a:b + 1].max() - ang[a:b + 1].min(),
                     np.abs(gyro[a:b + 1]).max(), clr[a:b + 1].max()))
    if len(rows) < 10:
        return None
    r = np.array(rows)
    return {"strides": int(len(r)), "cadence": float(120.0 / r[:, 0].mean()),
            "stance_pct": float(r[:, 1].mean()), "rom": float(r[:, 2].mean()),
            "peak_gyro": float(r[:, 3].mean()), "clearance_mm": float(r[:, 4].mean())}
