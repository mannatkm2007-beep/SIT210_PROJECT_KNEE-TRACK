"""Pi-side inference with the Colab-trained model (best.onnx). Runs on demand (e.g. when a
session ends), single-threaded, so it does not load the Pi during live recording.

  pip install onnxruntime numpy        (needs a 64-bit Raspberry Pi OS)
  python3 -m ml.onnx_infer --session 12
Place best.onnx and model_meta.json in ~/kneetrack_data/models/ (copied from Google Drive).
"""
import argparse
import json
import os
import sqlite3
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import config  # noqa: E402
from ml import kneetrack_prep as prep  # noqa: E402

MODEL_DIR = os.path.join(os.path.dirname(config.DB_PATH), "models")


def load_model(model_path=None, meta_path=None):
    import onnxruntime as ort
    model_path = model_path or os.path.join(MODEL_DIR, "best.onnx")
    meta_path = meta_path or os.path.join(MODEL_DIR, "model_meta.json")
    opts = ort.SessionOptions()
    opts.intra_op_num_threads = 1
    opts.inter_op_num_threads = 1
    sess = ort.InferenceSession(model_path, sess_options=opts, providers=["CPUExecutionProvider"])
    with open(meta_path) as fh:
        meta = json.load(fh)
    return sess, meta


def classify_rows(rows, sess, meta):
    """rows: tuples (ts, dev_ms, angle, gyro, fsr_unused, clearance_mm, acc_mg, flags)."""
    empty = {"windows": 0, "class_pct": {}, "stats": {}}
    if not rows:
        return empty
    a = np.array(rows, dtype=float)
    cols = {"angle": a[:, 2], "gyro": a[:, 3], "clearance_mm": a[:, 5], "acc_mg": a[:, 6]}
    segs, stats = prep.prepare_rows(a[:, 0], a[:, 1], cols, a[:, 7], trim_s=0.0)
    wins = [prep.make_windows(s) for s in segs]
    wins = [w for w in wins if len(w)]
    if not wins:
        return {**empty, "stats": stats}
    x = prep.normalise(np.concatenate(wins), meta["mean"], meta["std"])
    logits = np.concatenate([sess.run(None, {"window": x[i:i + 256]})[0] for i in range(0, len(x), 256)])
    e = np.exp(logits - logits.max(axis=1, keepdims=True))
    prob = e / e.sum(axis=1, keepdims=True)
    pred = prob.argmax(axis=1)
    classes = meta["classes"]
    return {"windows": int(len(pred)),
            "class_pct": {c: round(100.0 * float((pred == i).mean()), 1) for i, c in enumerate(classes)},
            "mean_confidence": round(float(prob.max(axis=1).mean()), 3), "stats": stats}


def classify_session(conn, start, end, sess, meta):
    rows = conn.execute("SELECT ts,dev_ms,angle,gyro,fsr,clearance_mm,acc_mg,flags FROM telemetry "
                        "WHERE ts BETWEEN ? AND ?", (start, end)).fetchall()
    return classify_rows(rows, sess, meta)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--session", type=int, required=True)
    a = ap.parse_args()
    conn = sqlite3.connect(config.DB_PATH)
    s = conn.execute("SELECT start_ts, end_ts FROM sessions WHERE id=?", (a.session,)).fetchone()
    if not s or s[1] is None:
        sys.exit("session not found or still running")
    model, meta = load_model()
    print(json.dumps(classify_session(conn, s[0], s[1], model, meta), indent=2))
